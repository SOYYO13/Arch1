window.onload = inicial;

var url1 = "http://localhost:3001/producto";
var url2 = "http://localhost:3001/Ventas";




function inicial()
{
        document.getElementById("list").addEventListener('click', listadoElementos);
        document.getElementById("Com").addEventListener('click', compraCliente);
        document.getElementById("listfac").addEventListener('click', listarFacturas);
        document.getElementById("toque1").addEventListener('click', borrarProd);
        document.getElementById("toque2").addEventListener('click', borrarFac);
        document.getElementById("modifi").addEventListener('click', modificarElemento);

}

//modifico ventas con id en el url y PUT(MODIFICA TODO EL ELEMENTO)
function modificarElemento(){
        let idModificar = document.getElementById("idModif").value;
        axios({
                method: 'PUT',
                url: "http://localhost:3001/Ventas"+"/"+idModificar,
                data: {
                "TipoDePago": document.getElementById("tipoModif").value,
                "Monto":  document.getElementById("montoModif").value,
                "NumCliente": document.getElementById("numModif").value,
                "NombreClient": document.getElementById("nomModif").value ,
                "Fecha": document.getElementById("fecModif").value,
                "Turno": document.getElementById("turModif").value,
                "Compra":{
                        "pops": document.getElementById("popMOD").value ,
                        "lay's": document.getElementById("laysMOD").value ,
                        "aguila":document.getElementById("aguilaMOD").value ,
                        "terrabussi":document.getElementById("terraMOD").value ,
                        "merengadas":document.getElementById("merenMOD").value  ,
                        "push":document.getElementById("pushMOD").value  ,
                        "oreo":document.getElementById("oreoMOD").value  ,
                        "gomitas": document.getElementById("gomitasMOD").value ,
                        "huevos kinder": document.getElementById("huevoMOD").value ,
                        "mantecol": document.getElementById("mantecolMOD").value ,
                        "pico dulce":document.getElementById("picodulceMOD").value  ,
                        "grandote":document.getElementById("grandoteMOD").value  ,
                        "chetos": document.getElementById("chetosMOD").value ,
                        "rueditas":document.getElementById("rueditasMOD").value  ,
                        "top line 7's": document.getElementById("toplineMOD").value 
                        }
                        
                }
        })
        .then(res => {console.log(res);})
        .catch(err => {console.log(err);} )
}

function listadoElementos(){
        axios.get("http://localhost:3001/Producto")
        .then (res => {
                        for(item of res.data){
                                console.log(item.id);
                                document.getElementById("salida1").innerHTML+= "<li>"+"ID: " +item.id+ ". "
                                document.getElementById("salida1").innerHTML+= "Tipo: " +item.Tipo+ ". "
                                document.getElementById("salida1").innerHTML+= "Marca: " +item.Marca+ ". "
                                document.getElementById("salida1").innerHTML+= "Precio/Compra: " +item.PrecioXuniComp+ ". "
                                document.getElementById("salida1").innerHTML+= "Precio/Venta: " +item.PrecioXuniVent+ ". "
                                document.getElementById("salida1").innerHTML+= "Unidad total: " +item.UniTotal+"</li>"+ "<br>"+ "<br>"
                        }
                } )
        .catch( err => {
                console.log(err)
                })
}

function listarFacturas(){
        
        axios.get("http://localhost:3001/Ventas")
        .then (res => {
                        console.log(res.data);
                        for(item of res.data){
                                
                                document.getElementById("salida2").innerHTML+= "<li>"+"ID: " +item.id+ ". "
                                document.getElementById("salida2").innerHTML+= "Tipo de pago: " +item.TipoDePago+ ". "
                                document.getElementById("salida2").innerHTML+= "Monto: " +item.Monto+ ". "
                                document.getElementById("salida2").innerHTML+= "Telefono del Cliente: " +item.NumCliente+ ". "
                                document.getElementById("salida2").innerHTML+= "Nombre de Client: " +item.NombreClient+ ". "
                                document.getElementById("salida2").innerHTML+= "Turno: " +item.Turno+ ". "
                                document.getElementById("salida2").innerHTML+= "Fecha: " +item.Fecha+ ". "
                                //JSON.stringify(item.Compra)
                                document.getElementById("salida2").innerHTML+= "Compra: "+ "-> "+ "<br>"  
                                for(let elem of item.Compra ){
                                        document.getElementById("salida2").innerHTML+= "Aguila: " +elem.aguila+ ".  "+ "<br>"  
                                        document.getElementById("salida2").innerHTML+= "Pops: " +elem.pops+ ".  "+ "<br>"  
                                        document.getElementById("salida2").innerHTML+= "Lays: " +elem.lay+ ".  "+ "<br>"  
                                        document.getElementById("salida2").innerHTML+= "Terrabussi: " +elem.terrabussi+ ".  "+ "<br>"  
                                        document.getElementById("salida2").innerHTML+="Merengadas: " +elem.merengadas+ ".  "+ "<br>"  
                                        document.getElementById("salida2").innerHTML+= "Push: " +elem.push+ ".  "+ "<br>"  
                                        document.getElementById("salida2").innerHTML+= "Oreo: " +elem.oreo+ ".  "+ "<br>"  
                                        document.getElementById("salida2").innerHTML+= "Gomitas: " +elem.gomitas+ ".  "+ "<br>"  
                                        document.getElementById("salida2").innerHTML+="Huevos kinder: " +elem.huevoskinder+ ".  "+ "<br>"  
                                        document.getElementById("salida2").innerHTML+= "Mantecol: " +elem.mantecol+ ".  "+ "<br>"  
                                        document.getElementById("salida2").innerHTML+= "Pico dulce: " +elem.picodulce+ ".  "+ "<br>"  
                                        document.getElementById("salida2").innerHTML+= "Grandote: " +elem.grandote+ ".  "+ "<br>"  
                                        document.getElementById("salida2").innerHTML+="Chetos: " +elem.chetos+ ".  "+ "<br>"  
                                        document.getElementById("salida2").innerHTML+= "Rueditas: " +elem.rueditas+ ".  "+ "<br>"  
                                        document.getElementById("salida2").innerHTML+= "Top line 7s: " +elem.topline+ "<br>"  
                                        
                                }
                        }
                } )
        .catch( err => {
                console.log(err)
                })
}

//para que me de la fecha del dia
let date = new Date();
var fecha = String(date.getDate()).padStart(2, '0') + '/' + String(date.getMonth() + 1).padStart(2, '0') + '/' + date.getFullYear();
//Compra del cliente POST para factura 
// y PUT modifica stock
function compraCliente(){
        //factura
        axios({
                method: 'POST',
                url:" http://localhost:3001/Ventas" ,
                data: {
                "TipoDePago": document.getElementById("Pago").value,
                "Monto": Math.floor(Math.random() * 1000) ,
                "NumCliente": document.getElementById("Cel").value,
                "NombreClient": document.getElementById("ApiNom").value ,
                "Fecha": fecha,
                "Turno": document.getElementById("Tur").value,
                "Compra":{
                        "pops": document.getElementById("pop").value ,
                        "lay's": document.getElementById("lays").value ,
                        "aguila":document.getElementById("aguila").value ,
                        "terrabussi":document.getElementById("terrabusi").value ,
                        "merengadas":document.getElementById("merengadas").value  ,
                        "push":document.getElementById("push").value  ,
                        "oreo":document.getElementById("oreo").value  ,
                        "gomitas": document.getElementById("gomitas").value ,
                        "huevos kinder": document.getElementById("huevo").value ,
                        "mantecol": document.getElementById("mantecol").value ,
                        "pico dulce":document.getElementById("picodulce").value  ,
                        "grandote":document.getElementById("grandote").value  ,
                        "chetos": document.getElementById("chetos").value ,
                        "rueditas":document.getElementById("rueditas").value  ,
                        "top line 7's": document.getElementById("topline").value 
                }  }
        })
                .then(res => {
                        console.log(res.data);
                alert("Compra realizada correctamente!")
        } )
        .catch(err => console.log(err))
        


}




function borrarProd(){//FALTA ELIMINAR ELELEMTO DE LA COMPRA EN VENTAS
        let vari = document.getElementById("borra1").value;
        console.log(vari);
        if(vari > 0 ){
                axios({
                        method: 'DELETE',
                        url: "http://localhost:3001/Producto"+"/"+vari 
                })
        .then (res => {
                        console.log(res.data);
                        alert("Se elimino el PRODUCTO correctamente");
        })
        .catch( err => {       console.log(vari);
                console.log(err)
                })
        
        }else{alert("Error de ID")}  
}

function borrarFac(){
        let vari = document.getElementById("borra2").value;
        
        if(vari > 0 ){
                axios({
                method: 'delete',
                url: 'http://localhost:3001/Ventas'+'/'+vari 
                })
        .then (res => {
                        console.log(res.data);
                        alert("Se elimino la VENTA correctamente");
        })
        .catch( err => {
                console.log(err)
                })
        }else{alert("Error de ID")}
}



